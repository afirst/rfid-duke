package smarthome.rfid.data;

public abstract class Shape {
	public abstract boolean contains(Location point);
}
