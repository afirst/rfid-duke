package smarthome.rfid.data;

public class U {
	public static void Print(Object o) {
		System.out.println(o);
	}
}
