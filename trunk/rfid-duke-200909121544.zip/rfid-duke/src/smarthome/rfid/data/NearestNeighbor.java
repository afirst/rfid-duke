package smarthome.rfid.data;

public class NearestNeighbor extends KNearestNeighbor {
	public NearestNeighbor() {
		super(1);
	}	
} 
